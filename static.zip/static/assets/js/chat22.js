function getCookie(name) {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(';').shift();
}

let lastAdminMessageCount = 0;
let isFirstLoad = true;

// **آرایه پیام‌های پیش‌فرض**
const defaultWelcomeMessages = [
  "سلام وقت شریف تون بخیر",
  "چطور میتونم کمک تون کنم؟",
  "تیم رنک صفر اماده ای پاسخگویی هست"
];

// **تابع نمایش پیام‌های خوشامدگویی**
function displayWelcomeMessages() {
  const container = document.getElementById('chatBox');
  container.innerHTML = ''; // پاک کردن محتوای قبلی
  defaultWelcomeMessages.forEach((text, index) => {
    setTimeout(() => { // نمایش با تاخیر برای زیبایی
      const messageDiv = document.createElement('div');
      messageDiv.className = 'message message-admin'; // پیام از طرف ادمین
      const timeString = new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
      messageDiv.innerHTML = `
        <div class="message-sender">پشتیبانی</div>
        <div class="message-content">${text}</div>
        <div class="message-time">${timeString}</div>
      `;
      container.appendChild(messageDiv);
      container.scrollTop = container.scrollHeight;
    }, index * 500); // تاخیر 500 میلی‌ثانیه‌ای بین هر پیام
  });
}

function sendMessage() {
  const text = document.getElementById('messageInput').value.trim();
  if (!text) return;

  // با ارسال اولین پیام، دیگر پیام‌های خوشامدگویی را نمایش نده
  sessionStorage.setItem('chat_welcomed', 'true');

  fetch('/chat/send/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCookie('csrftoken'),
    },
    body: JSON.stringify({ text })
  }).then(() => {
    document.getElementById('messageInput').value = '';
    isFirstLoad = true; // برای اینکه fetchMessages چت را از نو رندر کند
    fetchMessages();
  });
}

function fetchMessages() {
  if (sessionStorage.getItem('chat_welcomed') !== 'true') {
    return;
  }
  fetch('/chat/messages/')
    .then(res => res.json())
    .then(messages => {
      console.log("messages from server:", messages); // 🔍 لاگ برای تست
      const container = document.getElementById('chatBox');
      container.innerHTML = ''; // همیشه خالی کن و دوباره بساز
      messages.forEach(msg => {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${msg.is_from_admin ? 'message-admin' : 'message-user'}`;
        const timeString = new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
        messageDiv.innerHTML = `
          <div class="message-sender">${msg.is_from_admin ? 'پشتیبانی' : 'شما'}</div>
          <div class="message-content">${msg.text}</div>
          <div class="message-time">${timeString}</div>
        `;
        container.appendChild(messageDiv);
      });
      container.scrollTop = container.scrollHeight;
      isFirstLoad = false;
    })
    .catch(err => console.error("fetchMessages error:", err));
}


const chatToggle = document.getElementById('chatToggle');
const chatModal = document.getElementById('chatModal');
const chatClose = document.getElementById('chatClose');
const sendButton = document.getElementById('sendButton');
const messageInput = document.getElementById('messageInput');

chatToggle.addEventListener('click', () => {
  chatToggle.style.animation = 'none'; // توقف انیمیشن بعد از اولین کلیک
  chatModal.classList.toggle('active');

  if (chatModal.classList.contains('active')) {
    // **بررسی برای نمایش پیام خوشامدگویی**
    if (sessionStorage.getItem('chat_welcomed') !== 'true') {
      displayWelcomeMessages();
    } else {
      isFirstLoad = true; // برای رفرش کردن چت در باز شدن مجدد
      fetchMessages();
    }
  }
});

chatClose.addEventListener('click', () => {
  chatModal.classList.remove('active');
});

sendButton.addEventListener('click', sendMessage);
messageInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') sendMessage();
});

setInterval(() => {
  if (chatModal.classList.contains('active')) {
    fetchMessages();
  }
}, 3000);
